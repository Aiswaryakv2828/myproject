package karatetests;

import com.intuit.karate.junit5.Karate;

public class Runner {
	
	@Karate.Test
	Karate karateTest() {
		return Karate.run("classpath:karatetests/petstoretest.feature").relativeTo(getClass());   
		
	}

}


// karate reports will be generated in the target folder

// Integrated karate on the main project "petstoreuser"