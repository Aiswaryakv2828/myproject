package endpoints;

public class Routes {
	public static String baseUri="https://petstore.swagger.io/v2";
	public static String get_user="/user/{username}";
	public static String create_userwithList="/user/createWithList";
	public static String update_user="/user/{username}";
	public static String delete_user="/user/{username}";
	public static String get_login="/user/login";
	public static String get_logout="/user/logout";
	public static String create_userwitharray="/user/createWithArray";
	public static String create_user="/user";
}
