package endpoints;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.Usermodel;

public class UserEndpoints {

	public static Response getLogin() {
		Response response= RestAssured.given()
				.headers("Content-Type",
				ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_login)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	
	public static Response getLogout() {
		Response response= RestAssured.given()
				.headers("Content-Type",
				ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_logout)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	
	public static Response getSingleUser(String username) {
		Response response=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,
						"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_user)
				.pathParam("username",username)
				.contentType("application/json")
				.accept(ContentType.JSON).when()
                 .get();		
		return response;
		
	}
	
	public static Response createUserWithList(Usermodel payload) {
		Response response=RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.create_userwithList)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}
	
	public static Response updateUser(String username, Usermodel payload) {
		Response response=RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.update_user)
				.pathParam("username",username)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;
	}

	
	public static Response createUserWithArray(Usermodel payload) {
		Response response=RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.create_userwitharray)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}
	
	public static Response createUser(Usermodel payload) {
		Response response=RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.create_user)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}


	public static Response deleteUser(String username) {
		Response res =RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.delete_user)
				.pathParams("username", username)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when().delete();
		return res;
	}

	
}
