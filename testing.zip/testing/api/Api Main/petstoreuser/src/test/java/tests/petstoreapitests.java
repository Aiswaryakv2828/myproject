package tests;

import static org.testng.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

@Listeners(utilities.ExtentReportsListener.class)
public class petstoreapitests {
public Usermodel us;
public String projectPath;
	
	@BeforeTest
	public  void setup() {
		RestAssured.useRelaxedHTTPSValidation();
		us=new Usermodel("arun123","arun","kumar","arun@gmail.com","arun123","8723864623","1");
		projectPath = System.getProperty("user.dir");
	}
	
	@Test(priority=0)
	public void getSingleUser() {
		Response res=UserEndpoints.getSingleUser(this.us.username);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);	
		res.then().assertThat().body("firstName", equalTo("arun"));
		res.then().assertThat().body("email", equalTo("arun@gmail.com"));
		res.then().assertThat().body(matchesJsonSchema(new File(projectPath+"/src/test/resource/Data/userSchema.json")));
	}
	
	@Test(priority=1)
	public void createUserWithList() {
	Response res=UserEndpoints.createUserWithList(us);
	res.then().log().all();
	assertEquals(res.getStatusCode(),201);
		
	}
	
	
	@Test(priority=2)
	public void updateEmployeeDetails() {
		Response res=UserEndpoints.updateUser(this.us.username,us);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
				
	@Test(priority=3)
	public void deleteEmployee() {
		Response res=UserEndpoints.deleteUser(this.us.username);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
	
	@Test(priority=4)
	public void getLogin() {
		Response res=UserEndpoints.getLogin();
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
	
	@Test(priority=5)
	public void getLogout() {
		Response res=UserEndpoints.getLogout();
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
	
	@Test(priority=6)
	public void createUserWithArray() {
		Response res=UserEndpoints.createUserWithArray(us);
		res.then().log().all();
		assertEquals(res.getStatusCode(),201);
	}
	
	@Test(priority=7)
	public void createUser() {
		Response res=UserEndpoints.createUser(us);
		res.then().log().all();
		assertEquals(res.getStatusCode(),201);
	}

}