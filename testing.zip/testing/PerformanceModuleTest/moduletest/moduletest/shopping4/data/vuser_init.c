/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("kartmax_logo-grey.png", 
		"URL=https://kartmaxlogo.sgp1.digitaloceanspaces.com/kartmax_logo-grey.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("wrapper.php", 
		"URL=https://swopstore.com/wrapper.php?_isStatic=false&_isDev=false&_isHMR=false&_app=%5Bobject%20Object%5D&_store=%5Bobject%20Object%5D&_payload=undefined&_error=function%20()%20%7B%20%5Bnative%20code%5D%20%7D&_base=%2F&_env=%5Bobject%20Object%5D&_redirect=function(t%2Cpath%2Co)%7Bif(t)%7Be.context._redirected%3D!0%3Bvar%20n%3DObject(r.a)(path)%3Bif(%22number%22%3D%3Dtypeof%20t%7C%7C%22undefined%22!%3D%3Dn%26%26%22object%22!%3D%3Dn%7C%7C(o%3Dpath%7C%7C%7B%7D%2Cpath%3Dt%2Cn%3DObject(r.a)(path)"
		"%2Ct%3D302)%2C%22object%22%3D%3D%3Dn%26%26(path%3De.router.resolve(path).route.fullPath)%2C!%2F(%5E%5B.%5D%7B1%2C2%7D%5C%2F)%7C(%5E%5C%2F(%3F!%5C%2F))%2F.test(path))throw%20path%3DObject(m.d)(path%2Co)%2Cwindow.location.replace(path)%2Cnew%20Error(%22ERR_REDIRECT%22)%3Be.context.next(%7Bpath%3Apath%2Cquery%3Ao%2Cstatus%3At%7D)%7D%7D&_nuxtState=%5Bobject%20Object%5D&_route=%5Bobject%20Object%5D&_next=function(t)%7Breturn%20d.router.push(t)%7D&__redirected=false&__errored=false&_params="
		"%5Bobject%20Object%5D&_query=%5Bobject%20Object%5D&_$config=%5Bobject%20Object%5D&_$gtm=%5Bobject%20Object%5D&_$axios=function()%7Bfor(var%20n%3Dnew%20Array(arguments.length)%2Ci%3D0%3Bi%3Cn.length%3Bi%2B%2B)n%5Bi%5D%3Darguments%5Bi%5D%3Breturn%20t.apply(e%2Cn)%7D&_$device=%5Bobject%20Object%5D&method=main&jsc=iPromoCpnObj", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("uc.js", 
		"URL=https://sr-promise-prod.s3.ap-south-1.amazonaws.com/sr-promise/static/uc.js?channel_id=1", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("1694088870Shorts.webp", 
		"URL=https://stgadmin.getketch.com/category/1694088870Shorts.webp", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("1694088839Tshirts.webp", 
		"URL=https://stgadmin.getketch.com/category/1694088839Tshirts.webp", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("1694088813Jeans.webp", 
		"URL=https://stgadmin.getketch.com/category/1694088813Jeans.webp", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("1694088794Shirts.webp", 
		"URL=https://stgadmin.getketch.com/category/1694088794Shirts.webp", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("1694088855Trousers%20&%20Pants.webp", 
		"URL=https://stgadmin.getketch.com/category/1694088855Trousers%20&%20Pants.webp", 
		"Resource=1", 
		"RecContentType=image/webp", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t8.inf", 
		LAST);

	return 0;
}
