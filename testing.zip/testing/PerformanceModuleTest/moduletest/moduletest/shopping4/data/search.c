search()
{

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	lr_think_time(25);

	web_custom_request("autocomplete", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=t&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("autocomplete_2", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tsh&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("autocomplete_3", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tshi&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("autocomplete_4", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=t&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("autocomplete_5", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tsh&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("autocomplete_6", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tshi&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("autocomplete_7", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tshirt&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("autocomplete_8", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tshirt&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("autocomplete_9", 
		"URL=https://api.wizzy.ai/v1/autocomplete?q=tshirt&productsCount=6&suggestionsCount=6&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("search", 
		"URL=https://api.wizzy.ai/v1/products/search?q=tshirt&facets=[%7B%22key%22:%22filter_gender%22,%22label%22:%22Gender%22,%22position%22:%22left%22,%22order%22:12%7D,%7B%22key%22:%22filter_sub_category%22,%22label%22:%22Category%22,%22position%22:%22left%22,%22order%22:13%7D,%7B%22key%22:%22filter_size%22,%22label%22:%22Size%22,%22position%22:%22left%22,%22order%22:14%7D,%7B%22key%22:%22filter_brand%22,%22label%22:%22Brand%22,%22position%22:%22left%22,%22order%22:3%7D,%7B%22key%22"
		":%22filter_color_family%22,%22label%22:%22Colour%22,%22position%22:%22left%22,%22order%22:4%7D,%7B%22key%22:%22filter_top_type%22,%22label%22:%22Top+Type%22,%22position%22:%22left%22,%22order%22:47%7D,%7B%22key%22:%22filter_bottom_type%22,%22label%22:%22Bottom+Type%22,%22position%22:%22left%22,%22order%22:48%7D,%7B%22key%22:%22filter_top_fabric%22,%22label%22:%22Top+Fabric%22,%22position%22:%22left%22,%22order%22:45%7D,%7B%22key%22:%22filter_top_length%22,%22label%22:%22Top+Length%22,"
		"%22position%22:%22left%22,%22order%22:49%7D,%7B%22key%22:%22filter_fabric%22,%22label%22:%22Fabric%22,%22position%22:%22left%22,%22order%22:40%7D,%7B%22key%22:%22filter_type_of_pleat%22,%22label%22:%22Type+of+Pleat%22,%22position%22:%22left%22,%22order%22:65%7D,%7B%22key%22:%22filter_shape%22,%22label%22:%22Shape%22,%22position%22:%22left%22,%22order%22:54%7D,%7B%22key%22:%22filter_neck%22,%22label%22:%22Neck%22,%22position%22:%22left%22,%22order%22:51%7D,%7B%22key%22:%22filter_pattern%22,"
		"%22label%22:%22Pattern%22,%22position%22:%22left%22,%22order%22:43%7D,%7B%22key%22:%22filter_fit%22,%22label%22:%22Fit%22,%22position%22:%22left%22,%22order%22:42%7D,%7B%22key%22:%22filter_waist_rise%22,%22label%22:%22Waist+Rise%22,%22position%22:%22left%22,%22order%22:57%7D,%7B%22key%22:%22filter_distress%22,%22label%22:%22Distress%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_length%22,%22label%22:%22Length%22,%22position%22:%22left%22,%22order%22:52%7D,%7B%22key%22"
		":%22filter_sleeve_length%22,%22label%22:%22Sleeve+Length%22,%22position%22:%22left%22,%22order%22:50%7D,%7B%22key%22:%22filter_bottom_fabric%22,%22label%22:%22Bottom+Fabric%22,%22position%22:%22left%22,%22order%22:46%7D,%7B%22key%22:%22filter_design_styling%22,%22label%22:%22Design+Styling%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_main_trend%22,%22label%22:%22Main+Trend%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_type%22,%22label%22"
		":%22Type%22,%22position%22:%22left%22,%22order%22:56%7D,%7B%22key%22:%22filter_closure%22,%22label%22:%22Closure%22,%22position%22:%22left%22,%22order%22:41%7D,%7B%22key%22:%22filter_shade%22,%22label%22:%22Shade%22,%22position%22:%22left%22,%22order%22:58%7D,%7B%22key%22:%22filter_strech%22,%22label%22:%22Stretch%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_hood%22,%22label%22:%22Hood%22,%22position%22:%22left%22,%22order%22:64%7D,%7B%22key%22:%22filter_ply%22,"
		"%22label%22:%22Ply%22,%22position%22:%22left%22,%22order%22:59%7D,%7B%22key%22:%22filter_reusable%22,%22label%22:%22Reusable%22,%22position%22:%22left%22,%22order%22:60%7D,%7B%22key%22:%22filter_filtration%22,%22label%22:%22Filtration%22,%22position%22:%22left%22,%22order%22:61%7D,%7B%22key%22:%22filter_fastening%22,%22label%22:%22Fastening%22,%22position%22:%22left%22,%22order%22:62%7D,%7B%22key%22:%22filter_composition%22,%22label%22:%22Composition%22,%22position%22:%22left%22,%22order%22:100%7D"
		",%7B%22key%22:%22filter_brand_Size%22,%22label%22:%22Brand+Size%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22discountPercentage%22,%22label%22:%22Discount%22,%22position%22:%22left%22,%22order%22:1118%7D,%7B%22key%22:%22sellingPrice%22,%22label%22:%22Price%22,%22position%22:%22left%22,%22order%22:1118%7D]&sort=[%7B%22field%22:%22relevance%22,%22order%22:%22asc%22%7D]&includeOutOfStock=true", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("search_2", 
		"URL=https://api.wizzy.ai/v1/products/search?q=tshirt&facets=[%7B%22key%22:%22filter_gender%22,%22label%22:%22Gender%22,%22position%22:%22left%22,%22order%22:12%7D,%7B%22key%22:%22filter_sub_category%22,%22label%22:%22Category%22,%22position%22:%22left%22,%22order%22:13%7D,%7B%22key%22:%22filter_size%22,%22label%22:%22Size%22,%22position%22:%22left%22,%22order%22:14%7D,%7B%22key%22:%22filter_brand%22,%22label%22:%22Brand%22,%22position%22:%22left%22,%22order%22:3%7D,%7B%22key%22"
		":%22filter_color_family%22,%22label%22:%22Colour%22,%22position%22:%22left%22,%22order%22:4%7D,%7B%22key%22:%22filter_top_type%22,%22label%22:%22Top+Type%22,%22position%22:%22left%22,%22order%22:47%7D,%7B%22key%22:%22filter_bottom_type%22,%22label%22:%22Bottom+Type%22,%22position%22:%22left%22,%22order%22:48%7D,%7B%22key%22:%22filter_top_fabric%22,%22label%22:%22Top+Fabric%22,%22position%22:%22left%22,%22order%22:45%7D,%7B%22key%22:%22filter_top_length%22,%22label%22:%22Top+Length%22,"
		"%22position%22:%22left%22,%22order%22:49%7D,%7B%22key%22:%22filter_fabric%22,%22label%22:%22Fabric%22,%22position%22:%22left%22,%22order%22:40%7D,%7B%22key%22:%22filter_type_of_pleat%22,%22label%22:%22Type+of+Pleat%22,%22position%22:%22left%22,%22order%22:65%7D,%7B%22key%22:%22filter_shape%22,%22label%22:%22Shape%22,%22position%22:%22left%22,%22order%22:54%7D,%7B%22key%22:%22filter_neck%22,%22label%22:%22Neck%22,%22position%22:%22left%22,%22order%22:51%7D,%7B%22key%22:%22filter_pattern%22,"
		"%22label%22:%22Pattern%22,%22position%22:%22left%22,%22order%22:43%7D,%7B%22key%22:%22filter_fit%22,%22label%22:%22Fit%22,%22position%22:%22left%22,%22order%22:42%7D,%7B%22key%22:%22filter_waist_rise%22,%22label%22:%22Waist+Rise%22,%22position%22:%22left%22,%22order%22:57%7D,%7B%22key%22:%22filter_distress%22,%22label%22:%22Distress%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_length%22,%22label%22:%22Length%22,%22position%22:%22left%22,%22order%22:52%7D,%7B%22key%22"
		":%22filter_sleeve_length%22,%22label%22:%22Sleeve+Length%22,%22position%22:%22left%22,%22order%22:50%7D,%7B%22key%22:%22filter_bottom_fabric%22,%22label%22:%22Bottom+Fabric%22,%22position%22:%22left%22,%22order%22:46%7D,%7B%22key%22:%22filter_design_styling%22,%22label%22:%22Design+Styling%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_main_trend%22,%22label%22:%22Main+Trend%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_type%22,%22label%22"
		":%22Type%22,%22position%22:%22left%22,%22order%22:56%7D,%7B%22key%22:%22filter_closure%22,%22label%22:%22Closure%22,%22position%22:%22left%22,%22order%22:41%7D,%7B%22key%22:%22filter_shade%22,%22label%22:%22Shade%22,%22position%22:%22left%22,%22order%22:58%7D,%7B%22key%22:%22filter_strech%22,%22label%22:%22Stretch%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22filter_hood%22,%22label%22:%22Hood%22,%22position%22:%22left%22,%22order%22:64%7D,%7B%22key%22:%22filter_ply%22,"
		"%22label%22:%22Ply%22,%22position%22:%22left%22,%22order%22:59%7D,%7B%22key%22:%22filter_reusable%22,%22label%22:%22Reusable%22,%22position%22:%22left%22,%22order%22:60%7D,%7B%22key%22:%22filter_filtration%22,%22label%22:%22Filtration%22,%22position%22:%22left%22,%22order%22:61%7D,%7B%22key%22:%22filter_fastening%22,%22label%22:%22Fastening%22,%22position%22:%22left%22,%22order%22:62%7D,%7B%22key%22:%22filter_composition%22,%22label%22:%22Composition%22,%22position%22:%22left%22,%22order%22:100%7D"
		",%7B%22key%22:%22filter_brand_Size%22,%22label%22:%22Brand+Size%22,%22position%22:%22left%22,%22order%22:100%7D,%7B%22key%22:%22discountPercentage%22,%22label%22:%22Discount%22,%22position%22:%22left%22,%22order%22:1118%7D,%7B%22key%22:%22sellingPrice%22,%22label%22:%22Price%22,%22position%22:%22left%22,%22order%22:1118%7D]&sort=[%7B%22field%22:%22relevance%22,%22order%22:%22asc%22%7D]&includeOutOfStock=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(8);

	web_custom_request("click", 
		"URL=https://api.wizzy.ai/v1/events/click", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("click_2", 
		"URL=https://api.wizzy.ai/v1/events/click", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"name\":\"Search Results Clicked\",\"searchResponseId\":\"a8fbb9be-345e-11ef-bd55-0a6a11aebf00\",\"items\":[{\"itemId\":\"4652\",\"position\":1}]}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	return 0;
}
