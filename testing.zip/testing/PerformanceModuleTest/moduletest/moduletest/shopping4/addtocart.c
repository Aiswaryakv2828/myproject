addtocart()
{

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	lr_think_time(7);

	web_custom_request("converted", 
		"URL=https://api.wizzy.ai/v1/events/converted", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("converted_2", 
		"URL=https://api.wizzy.ai/v1/events/converted", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.getketch.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"name\":\"Product Added to Cart\",\"searchResponseId\":\"a8fbb9be-345e-11ef-bd55-0a6a11aebf00\",\"items\":[{\"itemId\":\"4653\",\"qty\":1}],\"id\":\"13400044\",\"value\":329,\"qty\":1}", 
		EXTRARES, 
		"Url=https://pragma-staticfiles-prod.s3.ap-south-1.amazonaws.com/custom-bs-checkout/custom-checkout.min.js?v=1.0.0", "Referer=https://www.getketch.com/", ENDITEM, 
		"Url=https://pragma-staticfiles-prod.s3.ap-south-1.amazonaws.com/custom-bs-checkout/1checkout-min.css?v=1.0.0", "Referer=https://www.getketch.com/", ENDITEM, 
		"Url=https://logisy-connect.s3.amazonaws.com/MerchantUploadedMedia/266/2296_1Checkoutlogo.png", "Referer=https://www.getketch.com/", ENDITEM, 
		LAST);

	return 0;
}