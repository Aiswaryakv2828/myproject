/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9669117647058824, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-14"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-13"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-16"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-15"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-10"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-12"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-11"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-6"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-7"], "isController": false}, {"data": [0.9, 500, 1500, "https://www.getketch.com/checkout-8"], "isController": false}, {"data": [0.9, 500, 1500, "https://www.getketch.com/checkout-9"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-2"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-3"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-4"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-5"], "isController": false}, {"data": [0.9, 500, 1500, "https://www.getketch.com/checkout-0"], "isController": false}, {"data": [0.9, 500, 1500, "https://www.getketch.com/checkout-1"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-25"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-24"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-21"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-20"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-23"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-22"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-18"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-17"], "isController": false}, {"data": [0.7, 500, 1500, "https://www.getketch.com/checkout"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.getketch.com/checkout-19"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 135, 0, 0.0, 82.17037037037036, 4, 1791, 14.0, 299.0, 489.19999999999925, 1395.719999999985, 35.68596352101507, 3676.6857900475816, 39.5607198321438], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://www.getketch.com/checkout-14", 5, 0, 0.0, 20.2, 11, 29, 19.0, 29.0, 29.0, 29.0, 2.232142857142857, 1.9683837890624998, 1.276942661830357], "isController": false}, {"data": ["https://www.getketch.com/checkout-13", 5, 0, 0.0, 29.6, 11, 58, 25.0, 58.0, 58.0, 58.0, 2.2222222222222223, 19.78689236111111, 1.3033854166666667], "isController": false}, {"data": ["https://www.getketch.com/checkout-16", 5, 0, 0.0, 19.4, 10, 52, 11.0, 52.0, 52.0, 52.0, 2.253267237494367, 3.1312492958539884, 1.302230030419108], "isController": false}, {"data": ["https://www.getketch.com/checkout-15", 5, 0, 0.0, 25.8, 10, 63, 15.0, 63.0, 63.0, 63.0, 2.2451728783116303, 9.199508166816345, 1.2751880332285588], "isController": false}, {"data": ["https://www.getketch.com/checkout-10", 5, 0, 0.0, 85.0, 13, 310, 43.0, 310.0, 310.0, 310.0, 1.827485380116959, 895.4514174433479, 1.0393823099415205], "isController": false}, {"data": ["https://www.getketch.com/checkout-12", 5, 0, 0.0, 21.8, 13, 41, 15.0, 41.0, 41.0, 41.0, 2.215330084182543, 3.455828394993354, 1.2625650753212228], "isController": false}, {"data": ["https://www.getketch.com/checkout-11", 5, 0, 0.0, 34.0, 10, 91, 17.0, 91.0, 91.0, 91.0, 2.232142857142857, 146.65047781808033, 1.2695312499999998], "isController": false}, {"data": ["https://www.getketch.com/checkout-6", 5, 0, 0.0, 99.99999999999999, 6, 465, 10.0, 465.0, 465.0, 465.0, 1.7182130584192439, 57.051385309278345, 0.9856233891752577], "isController": false}, {"data": ["https://www.getketch.com/checkout-7", 5, 0, 0.0, 16.6, 10, 27, 16.0, 27.0, 27.0, 27.0, 1.7743080198722496, 2.3980881831085874, 1.0063653300212916], "isController": false}, {"data": ["https://www.getketch.com/checkout-8", 5, 0, 0.0, 128.4, 11, 590, 13.0, 590.0, 590.0, 590.0, 1.8301610541727673, 82.46805797035138, 1.0409040995607612], "isController": false}, {"data": ["https://www.getketch.com/checkout-9", 5, 0, 0.0, 125.2, 10, 568, 11.0, 568.0, 568.0, 568.0, 1.8301610541727673, 111.78280563689604, 1.0409040995607612], "isController": false}, {"data": ["https://www.getketch.com/checkout-2", 5, 0, 0.0, 31.0, 12, 82, 14.0, 82.0, 82.0, 82.0, 1.7152658662092624, 11.884581367924529, 1.0526104202401372], "isController": false}, {"data": ["https://www.getketch.com/checkout-3", 5, 0, 0.0, 39.8, 10, 138, 17.0, 138.0, 138.0, 138.0, 1.7082336863682952, 31.396801332422275, 1.0075909634437992], "isController": false}, {"data": ["Test", 1, 0, 0.0, 3767.0, 3767, 3767, 3767.0, 3767.0, 3767.0, 3767.0, 0.26546323334218214, 1846.151094206265, 19.86437524887178], "isController": true}, {"data": ["https://www.getketch.com/checkout-4", 5, 0, 0.0, 32.8, 10, 107, 14.0, 107.0, 107.0, 107.0, 1.7146776406035664, 2.1731529706790123, 0.960822295096022], "isController": false}, {"data": ["https://www.getketch.com/checkout-5", 5, 0, 0.0, 28.6, 9, 76, 14.0, 76.0, 76.0, 76.0, 1.7146776406035664, 1.0894231181412894, 0.9728786222565158], "isController": false}, {"data": ["https://www.getketch.com/checkout-0", 5, 0, 0.0, 354.8, 289, 542, 302.0, 542.0, 542.0, 542.0, 1.369487811558477, 859.9495429334429, 0.674044782251438], "isController": false}, {"data": ["https://www.getketch.com/checkout-1", 5, 0, 0.0, 148.8, 12, 693, 13.0, 693.0, 693.0, 693.0, 1.7158544955387784, 6.252479945950583, 0.9812542896362388], "isController": false}, {"data": ["https://www.getketch.com/checkout-25", 5, 0, 0.0, 6.8, 6, 9, 6.0, 9.0, 9.0, 9.0, 2.3331777881474567, 7.207787709986001, 1.4231473110125994], "isController": false}, {"data": ["https://www.getketch.com/checkout-24", 5, 0, 0.0, 5.6, 4, 6, 6.0, 6.0, 6.0, 6.0, 2.3331777881474567, 2.158189454036398, 1.4190460219318712], "isController": false}, {"data": ["https://www.getketch.com/checkout-21", 5, 0, 0.0, 13.8, 12, 15, 14.0, 15.0, 15.0, 15.0, 2.3062730627306274, 4.243632524215867, 1.3459265452029519], "isController": false}, {"data": ["https://www.getketch.com/checkout-20", 5, 0, 0.0, 15.8, 11, 21, 15.0, 21.0, 21.0, 21.0, 2.3094688221709005, 4.315819861431871, 1.3365148672055427], "isController": false}, {"data": ["https://www.getketch.com/checkout-23", 5, 0, 0.0, 125.0, 66, 222, 68.0, 222.0, 222.0, 222.0, 2.2583559168925023, 2.1352931628274616, 1.3691282746160796], "isController": false}, {"data": ["https://www.getketch.com/checkout-22", 5, 0, 0.0, 15.8, 10, 21, 16.0, 21.0, 21.0, 21.0, 2.3052097740894424, 3.8702310972798526, 1.3498083794375288], "isController": false}, {"data": ["https://www.getketch.com/checkout-18", 5, 0, 0.0, 10.6, 9, 12, 11.0, 12.0, 12.0, 12.0, 2.311604253351826, 3.5346776756819236, 1.317433830328248], "isController": false}, {"data": ["https://www.getketch.com/checkout-17", 5, 0, 0.0, 18.4, 10, 39, 13.0, 39.0, 39.0, 39.0, 2.3137436372049978, 2.519359526839426, 1.3078074386857936], "isController": false}, {"data": ["https://www.getketch.com/checkout", 5, 0, 0.0, 753.4, 449, 1791, 476.0, 1791.0, 1791.0, 1791.0, 1.3217023526301876, 1838.3428950237908, 19.7803599160719], "isController": false}, {"data": ["https://www.getketch.com/checkout-19", 5, 0, 0.0, 11.6, 9, 14, 12.0, 14.0, 14.0, 14.0, 2.3126734505087883, 13.684070738899168, 1.3248185996762258], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 135, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
